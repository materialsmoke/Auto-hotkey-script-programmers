keyboard.send_keys("<ctrl>+<right>")
keyboard.send_keys("<shift>+<ctrl>+<left>")
