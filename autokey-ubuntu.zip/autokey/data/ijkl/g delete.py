keyboard.send_key("<delete>")
